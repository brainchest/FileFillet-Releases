--
-- feedback table
--
DROP TABLE IF EXISTS feedback.features;

CREATE SCHEMA IF NOT EXISTS feedback;

CREATE TABLE feedback.features (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP NOT NULL DEFAULT now(),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    status TEXT NOT NULL,
    count INT NOT NULL
);

ALTER TABLE analytics.apps ENABLE ROW LEVEL SECURITY;

CREATE POLICY feedback_select_for_insert
ON analytics.apps
AS PERMISSIVE
FOR SELECT
TO authenticated
USING (
    (select auth.jwt() -> 'user_metadata' ->> 'app_key') = app_key
);

CREATE POLICY apps_select_for_user
ON analytics.apps
AS PERMISSIVE
FOR SELECT
TO authenticated
USING (
    (select auth.uid()) = user_id
);
